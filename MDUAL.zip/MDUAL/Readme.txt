README for MDUAL

This project uses the MDUAL algorithm to detect outliers in streaming data. Please use the Visual Studio Code (VS Code) IDE to compile and run the project.

How to Set Up and Run the Project in VS Code:

1. First, unzip the provided MDUAL folder.(All the required datasets are provided in the zip file)
2. Open Visual Studio Code.
3. Go to File → Open Folder and select the unzipped MDUAL project folder.
4. Install the necessary extensions (like C++, Code Runner)
5. Open the Terminal and select the new terminal.

6. Go to src folder by using the command. 

cd src


7. Compile the project using the command below

clang++ -std=c++17 \
  test/testLoad.cpp \
  MDUAL/MDUAL.cpp \
  MDUAL/Utils.cpp \
  MDUAL/Cell.cpp \
  MDUAL/globalCell.cpp \
  simulator/QueryGenerator.cpp \
  simulator/Simulator.cpp \
  simulator/MemoryThread.cpp \
  loader/DataLoader.cpp \
  loader/QueryLoader.cpp \
  simulator/Measure.cpp \
  -o testLoad

8. After compiling, run the program using 

./testLoad



Main Project Files:

1. test/testLoad.cpp - The main file that runs everything.
2. MDUAL/MDUAL.cpp - Has the main MDUAL algorithm for detecting outliers.
3. MDUAL/Utils.cpp - Contains small helper functions used throughout the project.
4. MDUAL/Cell.cpp - Manages small sections (cells) of the data space.
5. MDUAL/globalCell.cpp - Handles and connects all the cells together.
6. loader/DataLoader.cpp - Loads the dataset into the program.
7. loader/QueryLoader.cpp - Loads the queries that the algorithm will use.
8. simulator/Simulator.cpp - Runs the whole simulation and applies the algorithm.
9. simulator/QueryGenerator.cpp - Creates new queries while the simulation is running.
10. simulator/MemoryThread.cpp - Keeps track of how much memory is being used.
11. simulator/Measure.cpp - Measures and records time and memory usage during the run.