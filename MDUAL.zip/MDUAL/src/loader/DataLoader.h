#pragma once
#include <string>
#include <vector>
#include "Tuple.h"

class DataLoader {
private:
    std::vector<double> minValues;
    std::vector<double> maxValues;
    std::string filePath;
    std::vector<int> priorityList;

public:
    int dim;
    int subDim;

    DataLoader(const std::string& dataset);
    std::vector<Tuple> getNewSlideTuples(int itr, int S);
    const std::vector<double>& getMinValues() const;
    const std::vector<double>& getMaxValues() const;
};
