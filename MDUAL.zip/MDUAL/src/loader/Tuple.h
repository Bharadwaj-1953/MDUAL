#pragma once
#include <vector>
#include <set>

struct Tuple {
    std::vector<double> value;
    std::vector<short> fullDimCellIdx;
    std::vector<short> subDimCellIdx;
    int slideID;
    std::set<int> outlierQueryIDs;
    int id; 
    Tuple() = default;
    Tuple(int id_, int slideID_, const std::vector<double>& value_)
        : value(value_), slideID(slideID_), id(id_) {}
};
