#pragma once

#include "Query.h"
#include <string>
#include <unordered_map>

class QueryLoader {
public:
    int maxW;
    int gcdS;
    double minR;

private:
    std::string filePath;

public:
    QueryLoader(const std::string& queryset);
    std::unordered_map<int, Query> getQuerySet(int curr_itr);
    std::unordered_map<int, Query> getQuerySetByQID(int fromQID, int numQueries);
};
