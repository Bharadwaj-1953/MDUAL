#pragma once
#include <vector>
#include <unordered_map>
#include "../loader/Query.h"
#include "Cell.h"

class globalCell {
public:
    std::vector<short> cellIdx;
    std::unordered_map<std::vector<short>, double, VecShortHash, VecShortEq> neighCellMap;
    bool lastUpdated;
    int card;
    std::unordered_map<int, int> cardPerSlide;
    std::vector<int> IndirectOutlierCellQueryIDs = {};
    std::vector<Query> ndQueries = {}; 

    globalCell();
    globalCell(const std::vector<short>& cIdx);

    int getCardTotal(int firstSlideID) const;
    std::vector<std::vector<short>> getThredNeighCellsOut(double distThred) const;
    std::vector<std::vector<short>> getThredNeighCellsIn(double distThred) const;
};
